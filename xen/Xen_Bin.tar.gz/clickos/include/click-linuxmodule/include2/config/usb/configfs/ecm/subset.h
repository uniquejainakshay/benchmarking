/* created by click/linuxmodule/fixincludes.pl on Fri Dec 26 19:48:54 2014 */
/* from /lib/modules/3.13.0-24-generic/build/include/config/usb/configfs/ecm/subset.h */
